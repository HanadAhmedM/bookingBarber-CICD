import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=ae227a19";
import "/src/App.css";
var _jsxFileName = "/Users/hanadahmed/bookingBarber-CICD/frontend/src/App.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ae227a19";
var _s = $RefreshSig$();
const services = [
	{
		id: 1,
		name: "Haircut",
		description: "Klassisk klippning",
		price: "350 kr",
		duration: "30 min"
	},
	{
		id: 2,
		name: "Beard Trim",
		description: "Trimning och formning av skägg",
		price: "250 kr",
		duration: "20 min"
	},
	{
		id: 3,
		name: "Haircut & Beard",
		description: "Klippning + skägg",
		price: "500 kr",
		duration: "45 min"
	}
];
const barbers = [
	"Ahmed",
	"Mohammed",
	"Ali"
];
const times = [
	"10:00",
	"11:00",
	"12:00",
	"13:00",
	"14:00",
	"15:00",
	"16:00",
	"17:00"
];
function getWeekDays() {
	const days = [];
	for (let i = 0; i < 7; i++) {
		const date = new Date();
		date.setHours(0, 0, 0, 0);
		date.setDate(date.getDate() + i);
		const dateString = `${date.getFullYear()}-` + `${String(date.getMonth() + 1).padStart(2, "0")}-` + `${String(date.getDate()).padStart(2, "0")}`;
		days.push({
			date: dateString,
			dayName: date.toLocaleDateString("sv-SE", { weekday: "short" }),
			dayNumber: date.getDate(),
			month: date.toLocaleDateString("sv-SE", { month: "short" })
		});
	}
	return days;
}
function App() {
	_s();
	const [page, setPage] = useState("home");
	const [step, setStep] = useState(1);
	const [bookings, setBookings] = useState([]);
	const [booking, setBooking] = useState({
		service: null,
		barber: "",
		date: "",
		time: "",
		customerName: "",
		customerEmail: ""
	});
	const [confirmedBooking, setConfirmedBooking] = useState(null);
	const [message, setMessage] = useState("");
	const weekDays = getWeekDays();
	useEffect(() => {
		loadBookings();
	}, []);
	const loadBookings = async () => {
		try {
			const response = await fetch("/api/bookings");
			if (!response.ok) {
				throw new Error("Kunde inte hämta bokningar");
			}
			const data = await response.json();
			setBookings(data);
		} catch (error) {
			console.error(error);
		}
	};
	const goToPage = (newPage) => {
		setPage(newPage);
		setMessage("");
		if (newPage === "booking") {
			setStep(1);
			setConfirmedBooking(null);
		}
	};
	const selectService = (service) => {
		setBooking({
			...booking,
			service
		});
	};
	const selectBarber = (barber) => {
		setBooking({
			...booking,
			barber
		});
	};
	const selectDate = (date) => {
		setBooking({
			...booking,
			date,
			time: ""
		});
	};
	const selectTime = (time) => {
		setBooking({
			...booking,
			time
		});
	};
	const isTimeBooked = (date, time) => {
		return bookings.some((item) => item.bookingDate === date && item.bookingTime.startsWith(time));
	};
	const continueToNextStep = () => {
		if (step === 1 && !booking.service) {
			setMessage("Välj en behandling först.");
			return;
		}
		if (step === 2 && !booking.barber) {
			setMessage("Välj en barberare först.");
			return;
		}
		if (step === 3 && (!booking.date || !booking.time)) {
			setMessage("Välj datum och tid först.");
			return;
		}
		setMessage("");
		setStep(step + 1);
	};
	const goBack = () => {
		if (step > 1) {
			setMessage("");
			setStep(step - 1);
		}
	};
	const handleInputChange = (event) => {
		setBooking({
			...booking,
			[event.target.name]: event.target.value
		});
	};
	const handleSubmit = async (event) => {
		event.preventDefault();
		setMessage("Bokningen sparas...");
		try {
			const response = await fetch("/api/bookings", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					customerName: booking.customerName,
					customerEmail: booking.customerEmail,
					barber: booking.barber,
					service: booking.service.name,
					bookingDate: booking.date,
					bookingTime: `${booking.time}:00`
				})
			});
			if (!response.ok) {
				throw new Error("Bokningen kunde inte sparas.");
			}
			const savedBooking = await response.json();
			setConfirmedBooking(savedBooking);
			setMessage("");
			await loadBookings();
		} catch (error) {
			setMessage(error.message);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "site-header",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "header-inner",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							className: "brand",
							onClick: () => goToPage("home"),
							children: [/* @__PURE__ */ _jsxDEV("img", {
								src: "/diamond-logo.jpg",
								alt: "Diamond Barbershop"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 238,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "brand-text",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "DIAMOND" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 244,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("small", { children: "BARBERSHOP" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 245,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 243,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("nav", {
							className: "main-nav",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => goToPage("home"),
									children: "Hem"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 251,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => goToPage("services"),
									children: "Tjänster"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 255,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => goToPage("booking"),
									children: "Boka tid"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => goToPage("bookings"),
									children: "Mina bokningar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 263,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => goToPage("contact"),
									children: "Kontakt"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 267,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 249,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: "header-book-button",
							onClick: () => goToPage("booking"),
							children: "Boka tid"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 273,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: "mobile-menu",
							children: "☰"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 280,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 232,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 231,
				columnNumber: 7
			}, this),
			page === "home" && /* @__PURE__ */ _jsxDEV("main", { children: [/* @__PURE__ */ _jsxDEV("section", {
				className: "hero",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "hero-content",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "hero-label",
							children: "DIAMOND BARBERSHOP"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 296,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", { children: [
							"Din stil.",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 302,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Din tid." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 300,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Professionell barbering med personlig service." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 306,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: "hero-button",
							onClick: () => goToPage("booking"),
							children: "Boka din tid"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 310,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 294,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 292,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("section", {
				className: "home-section",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "section-label",
						children: "DIAMOND EXPERIENCE"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 323,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", { children: "En enkel väg till din nästa look" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 327,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "feature-grid",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "feature-card",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "01" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 334,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", { children: "Välj behandling" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 335,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: "Välj den behandling som passar dig." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 336,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 333,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "feature-card",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "02" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 342,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", { children: "Välj tid" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 343,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: "Se hela veckan och välj en ledig tid." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 344,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "feature-card",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "03" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 350,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", { children: "Bekräfta" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 351,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: "Fyll i dina uppgifter och bekräfta." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 352,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 331,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 321,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 290,
				columnNumber: 9
			}, this),
			page === "services" && /* @__PURE__ */ _jsxDEV("main", {
				className: "page-container",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "page-heading",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "section-label",
								children: "DIAMOND BARBERSHOP"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 370,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", { children: "Våra tjänster" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 374,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Välj den behandling som passar din stil." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 376,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 369,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "services-page-grid",
						children: services.map((service) => /* @__PURE__ */ _jsxDEV("div", {
							className: "large-service-card",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "service-number",
									children: ["0", service.id]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 386,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h2", { children: service.name }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: service.description }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 392,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "service-bottom",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: service.duration }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 395,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("strong", { children: service.price }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 396,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 394,
									columnNumber: 17
								}, this)
							]
						}, service.id, true, {
							fileName: _jsxFileName,
							lineNumber: 384,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 381,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "center-button",
						children: /* @__PURE__ */ _jsxDEV("button", {
							className: "hero-button",
							onClick: () => goToPage("booking"),
							children: "Boka behandling"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 406,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 404,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 367,
				columnNumber: 9
			}, this),
			page === "booking" && /* @__PURE__ */ _jsxDEV("main", {
				className: "booking-container",
				children: confirmedBooking ? /* @__PURE__ */ _jsxDEV(
					"div",
					/* CONFIRMATION */
					{
						className: "confirmation-page",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "success-icon",
								children: "✓"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 429,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "section-label",
								children: "DIAMOND BARBERSHOP"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 433,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", { children: "Bokningen är bekräftad" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 437,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Vi ser fram emot att träffa dig." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 439,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "confirmed-card",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Behandling" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 446,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("strong", { children: confirmedBooking.service }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 447,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 445,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Barberare" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 453,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("strong", { children: confirmedBooking.barber }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 454,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 452,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Datum" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 460,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("strong", { children: confirmedBooking.bookingDate }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 461,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 459,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Tid" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 467,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("strong", { children: confirmedBooking.bookingTime.substring(0, 5) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 468,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 466,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 443,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "confirmation-time",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "DIN BOKADE TID" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 477,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("strong", { children: confirmedBooking.bookingDate }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 479,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("b", { children: confirmedBooking.bookingTime.substring(0, 5) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 483,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 475,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "continue-button",
								onClick: () => goToPage("bookings"),
								children: "Visa mina bokningar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 489,
								columnNumber: 15
							}, this)
						]
					},
					void 0,
					true,
					{
						fileName: _jsxFileName,
						lineNumber: 427,
						columnNumber: 13
					},
					this
				) : 
				/* BOOKING FLOW */
				/* @__PURE__ */ _jsxDEV("div", {
					className: "booking-card",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "booking-header",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "section-label",
									children: "DIAMOND BARBERSHOP"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 506,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h1", { children: "Boka tid" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 510,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: "Välj behandling, barberare och tid." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 512,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 504,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "steps",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: `step ${step >= 1 ? "active" : ""}`,
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "1" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 523,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Behandling" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 524,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 522,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { className: "step-line" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 527,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: `step ${step >= 2 ? "active" : ""}`,
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "2" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 530,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Barberare" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 531,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 529,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { className: "step-line" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 534,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: `step ${step >= 3 ? "active" : ""}`,
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "3" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 537,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Tid" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 538,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 536,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { className: "step-line" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 541,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: `step ${step >= 4 ? "active" : ""}`,
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 544,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Bekräfta" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 545,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 543,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 520,
							columnNumber: 15
						}, this),
						message && /* @__PURE__ */ _jsxDEV("div", {
							className: "message",
							children: message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 551,
							columnNumber: 17
						}, this),
						step === 1 && /* @__PURE__ */ _jsxDEV("section", {
							className: "step-content",
							children: [
								/* @__PURE__ */ _jsxDEV("h2", { children: "Välj behandling" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 561,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "step-description",
									children: "Vad vill du boka?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 563,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "service-list",
									children: services.map((service) => /* @__PURE__ */ _jsxDEV("button", {
										className: `service-card ${booking.service?.id === service.id ? "selected" : ""}`,
										onClick: () => selectService(service),
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "service-info",
											children: [
												/* @__PURE__ */ _jsxDEV("h3", { children: service.name }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 583,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("p", { children: service.description }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 585,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("span", { children: service.duration }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 587,
													columnNumber: 27
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 581,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("strong", { children: service.price }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 593,
											columnNumber: 25
										}, this)]
									}, service.id, true, {
										fileName: _jsxFileName,
										lineNumber: 571,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 567,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 559,
							columnNumber: 17
						}, this),
						step === 2 && /* @__PURE__ */ _jsxDEV("section", {
							className: "step-content",
							children: [
								/* @__PURE__ */ _jsxDEV("h2", { children: "Välj barberare" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 611,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "step-description",
									children: "Vem vill du boka hos?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 613,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "barber-list",
									children: barbers.map((barber) => /* @__PURE__ */ _jsxDEV("button", {
										className: `barber-card ${booking.barber === barber ? "selected" : ""}`,
										onClick: () => selectBarber(barber),
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "barber-avatar",
											children: barber.charAt(0)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 631,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", { children: barber }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 636,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Barberare" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 637,
											columnNumber: 27
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 635,
											columnNumber: 25
										}, this)]
									}, barber, true, {
										fileName: _jsxFileName,
										lineNumber: 621,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 617,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 609,
							columnNumber: 17
						}, this),
						step === 3 && /* @__PURE__ */ _jsxDEV("section", {
							className: "step-content",
							children: [
								/* @__PURE__ */ _jsxDEV("h2", { children: "Välj datum och tid" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 654,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "step-description",
									children: "Se hela veckans tillgängliga tider."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 656,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "week-list",
									children: weekDays.map((day) => /* @__PURE__ */ _jsxDEV("div", {
										className: `day-column ${booking.date === day.date ? "selected-day" : ""}`,
										children: [/* @__PURE__ */ _jsxDEV("button", {
											className: "day-header",
											"data-testid": `day-${day.date}`,
											onClick: () => selectDate(day.date),
											children: [
												/* @__PURE__ */ _jsxDEV("span", { children: day.dayName }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 678,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("strong", { children: day.dayNumber }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 682,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("small", { children: day.month }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 686,
													columnNumber: 27
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 673,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "day-times",
											children: times.map((time) => {
												const booked = isTimeBooked(day.date, time);
												const selected = booking.date === day.date && booking.time === time;
												return /* @__PURE__ */ _jsxDEV("button", {
													disabled: booked,
													"data-testid": `time-${day.date}-${time}`,
													className: `week-time ${selected ? "selected" : ""} ${booked ? "booked" : ""}`,
													onClick: () => {
														setBooking({
															...booking,
															date: day.date,
															time
														});
													},
													children: booked ? "Bokad" : time
												}, time, false, {
													fileName: _jsxFileName,
													lineNumber: 705,
													columnNumber: 31
												}, this);
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 691,
											columnNumber: 25
										}, this)]
									}, day.date, true, {
										fileName: _jsxFileName,
										lineNumber: 664,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 660,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 652,
							columnNumber: 17
						}, this),
						step === 4 && /* @__PURE__ */ _jsxDEV("section", {
							className: "step-content",
							children: [
								/* @__PURE__ */ _jsxDEV("h2", { children: "Bekräfta bokning" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 739,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "step-description",
									children: "Kontrollera din bokning."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 741,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "confirmation",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Behandling" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 748,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("strong", { children: booking.service?.name }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 749,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 747,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Barberare" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 755,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("strong", { children: booking.barber }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 756,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 754,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Datum" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 762,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("strong", { children: booking.date }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 763,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 761,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Tid" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 769,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("strong", { children: booking.time }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 770,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 768,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Pris" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 776,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("strong", { children: booking.service?.price }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 777,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 775,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 745,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("form", {
									id: "booking-form",
									onSubmit: handleSubmit,
									children: [
										/* @__PURE__ */ _jsxDEV("label", { children: "Namn" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 789,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											className: "text-input",
											type: "text",
											name: "customerName",
											placeholder: "Ditt namn",
											value: booking.customerName,
											onChange: handleInputChange,
											required: true
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 791,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("label", { children: "E-post" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 801,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											className: "text-input",
											type: "email",
											name: "customerEmail",
											placeholder: "Din e-post",
											value: booking.customerEmail,
											onChange: handleInputChange,
											required: true
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 803,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 784,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 737,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "navigation",
							children: [step > 1 ? /* @__PURE__ */ _jsxDEV("button", {
								className: "back-button",
								onClick: goBack,
								children: "← Tillbaka"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 823,
								columnNumber: 19
							}, this) : /* @__PURE__ */ _jsxDEV("div", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 830,
								columnNumber: 19
							}, this), step < 4 ? /* @__PURE__ */ _jsxDEV("button", {
								className: "continue-button",
								onClick: continueToNextStep,
								children: "Fortsätt →"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 834,
								columnNumber: 19
							}, this) : /* @__PURE__ */ _jsxDEV("button", {
								className: "continue-button",
								type: "submit",
								form: "booking-form",
								children: "Bekräfta bokning"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 841,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 820,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 502,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 421,
				columnNumber: 9
			}, this),
			page === "bookings" && /* @__PURE__ */ _jsxDEV("main", {
				className: "page-container",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "page-heading",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "section-label",
							children: "DIAMOND BARBERSHOP"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 865,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", { children: "Mina bokningar" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 869,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Här ser du dina bokade tider." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 871,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 863,
					columnNumber: 11
				}, this), bookings.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "empty-bookings",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", { children: "Inga bokningar ännu" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 880,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Boka din första tid hos Diamond Barbershop." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 882,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: "hero-button",
							onClick: () => goToPage("booking"),
							children: "Boka tid"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 886,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 879,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "booking-history",
					children: bookings.map((item) => /* @__PURE__ */ _jsxDEV("div", {
						className: "history-card",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "history-date",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: item.bookingDate }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 907,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("strong", { children: item.bookingTime.substring(0, 5) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 911,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 905,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "history-info",
							children: [
								/* @__PURE__ */ _jsxDEV("h3", { children: item.service }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 919,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: ["Barberare: ", item.barber] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 921,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: item.customerName }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 925,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 917,
							columnNumber: 19
						}, this)]
					}, item.id, true, {
						fileName: _jsxFileName,
						lineNumber: 900,
						columnNumber: 17
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 896,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 861,
				columnNumber: 9
			}, this),
			page === "contact" && /* @__PURE__ */ _jsxDEV("main", {
				className: "page-container",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "page-heading",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "section-label",
							children: "DIAMOND BARBERSHOP"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 949,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", { children: "Kontakta oss" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 953,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Vi hjälper dig gärna." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 955,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 947,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "contact-grid",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "contact-card",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "ADRESS" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 964,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", { children: "Stockholm" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 965,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: "Besök oss för din nästa klippning." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 966,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 963,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "contact-card",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "TELEFON" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 972,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", { children: "08-123 45 67" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 973,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: "Ring oss under våra öppettider." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 974,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 971,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "contact-card",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "E-POST" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 980,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", { children: "info@diamondbarbershop.se" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 981,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: "Vi svarar så snart vi kan." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 982,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 979,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 961,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 945,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "footer",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "footer-logo",
					children: ["DIAMOND", /* @__PURE__ */ _jsxDEV("span", { children: "BARBERSHOP" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 996,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 994,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: "© 2026 Diamond Barbershop" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 999,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 992,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 227,
		columnNumber: 5
	}, this);
}
_s(App, "x6qxuXVcDZRGeT22fCwwtSMVtgY=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx?t=1790860264838";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/hanadahmed/bookingBarber-CICD/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/hanadahmed/bookingBarber-CICD/frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/hanadahmed/bookingBarber-CICD/frontend/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxPQUFPOzs7O0FBRVAsTUFBTSxXQUFXO0NBQ2Y7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLGFBQWE7RUFDYixPQUFPO0VBQ1AsVUFBVTtDQUNaO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLGFBQWE7RUFDYixPQUFPO0VBQ1AsVUFBVTtDQUNaO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLGFBQWE7RUFDYixPQUFPO0VBQ1AsVUFBVTtDQUNaO0FBQ0Y7QUFFQSxNQUFNLFVBQVU7Q0FBQztDQUFTO0NBQVk7QUFBSztBQUUzQyxNQUFNLFFBQVE7Q0FDWjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Y7QUFFQSxTQUFTLGNBQWM7Q0FDckIsTUFBTSxPQUFPLENBQUM7Q0FFZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0VBQzFCLE1BQU0sT0FBTyxJQUFJLEtBQUs7RUFDdEIsS0FBSyxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDeEIsS0FBSyxRQUFRLEtBQUssUUFBUSxJQUFJLENBQUM7RUFFL0IsTUFBTSxhQUNKLEdBQUcsS0FBSyxZQUFZLEVBQUUsS0FDdEIsR0FBRyxPQUFPLEtBQUssU0FBUyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsS0FDaEQsR0FBRyxPQUFPLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztFQUUzQyxLQUFLLEtBQUs7R0FDUixNQUFNO0dBQ04sU0FBUyxLQUFLLG1CQUFtQixTQUFTLEVBQ3hDLFNBQVMsUUFDWCxDQUFDO0dBQ0QsV0FBVyxLQUFLLFFBQVE7R0FDeEIsT0FBTyxLQUFLLG1CQUFtQixTQUFTLEVBQ3RDLE9BQU8sUUFDVCxDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBRUEsT0FBTztBQUNUO0FBRUEsU0FBUyxNQUFNOztDQUNiLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxNQUFNO0NBQ3ZDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxDQUFDO0NBRWxDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxDQUFDLENBQUM7Q0FFM0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTO0VBQ3JDLFNBQVM7RUFDVCxRQUFRO0VBQ1IsTUFBTTtFQUNOLE1BQU07RUFDTixjQUFjO0VBQ2QsZUFBZTtDQUNqQixDQUFDO0NBRUQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxJQUFJO0NBQzdELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBRXpDLE1BQU0sV0FBVyxZQUFZO0NBRTdCLGdCQUFnQjtFQUNkLGFBQWE7Q0FDZixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sZUFBZSxZQUFZO0VBQy9CLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUFNLGVBQWU7R0FFNUMsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixNQUFNLElBQUksTUFBTSw0QkFBNEI7R0FDOUM7R0FFQSxNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUs7R0FDakMsWUFBWSxJQUFJO0VBQ2xCLFNBQVMsT0FBTztHQUNkLFFBQVEsTUFBTSxLQUFLO0VBQ3JCO0NBQ0Y7Q0FFQSxNQUFNLFlBQVksWUFBWTtFQUM1QixRQUFRLE9BQU87RUFDZixXQUFXLEVBQUU7RUFFYixJQUFJLFlBQVksV0FBVztHQUN6QixRQUFRLENBQUM7R0FDVCxvQkFBb0IsSUFBSTtFQUMxQjtDQUNGO0NBRUEsTUFBTSxpQkFBaUIsWUFBWTtFQUNqQyxXQUFXO0dBQ1QsR0FBRztHQUNIO0VBQ0YsQ0FBQztDQUNIO0NBRUEsTUFBTSxnQkFBZ0IsV0FBVztFQUMvQixXQUFXO0dBQ1QsR0FBRztHQUNIO0VBQ0YsQ0FBQztDQUNIO0NBRUEsTUFBTSxjQUFjLFNBQVM7RUFDM0IsV0FBVztHQUNULEdBQUc7R0FDSDtHQUNBLE1BQU07RUFDUixDQUFDO0NBQ0g7Q0FFQSxNQUFNLGNBQWMsU0FBUztFQUMzQixXQUFXO0dBQ1QsR0FBRztHQUNIO0VBQ0YsQ0FBQztDQUNIO0NBRUEsTUFBTSxnQkFBZ0IsTUFBTSxTQUFTO0VBQ25DLE9BQU8sU0FBUyxNQUNiLFNBQ0MsS0FBSyxnQkFBZ0IsUUFDckIsS0FBSyxZQUFZLFdBQVcsSUFBSSxDQUNwQztDQUNGO0NBRUEsTUFBTSwyQkFBMkI7RUFDL0IsSUFBSSxTQUFTLEtBQUssQ0FBQyxRQUFRLFNBQVM7R0FDbEMsV0FBVywyQkFBMkI7R0FDdEM7RUFDRjtFQUVBLElBQUksU0FBUyxLQUFLLENBQUMsUUFBUSxRQUFRO0dBQ2pDLFdBQVcsMEJBQTBCO0dBQ3JDO0VBQ0Y7RUFFQSxJQUFJLFNBQVMsTUFBTSxDQUFDLFFBQVEsUUFBUSxDQUFDLFFBQVEsT0FBTztHQUNsRCxXQUFXLDJCQUEyQjtHQUN0QztFQUNGO0VBRUEsV0FBVyxFQUFFO0VBQ2IsUUFBUSxPQUFPLENBQUM7Q0FDbEI7Q0FFQSxNQUFNLGVBQWU7RUFDbkIsSUFBSSxPQUFPLEdBQUc7R0FDWixXQUFXLEVBQUU7R0FDYixRQUFRLE9BQU8sQ0FBQztFQUNsQjtDQUNGO0NBRUEsTUFBTSxxQkFBcUIsVUFBVTtFQUNuQyxXQUFXO0dBQ1QsR0FBRztJQUNGLE1BQU0sT0FBTyxPQUFPLE1BQU0sT0FBTztFQUNwQyxDQUFDO0NBQ0g7Q0FFQSxNQUFNLGVBQWUsT0FBTyxVQUFVO0VBQ3BDLE1BQU0sZUFBZTtFQUVyQixXQUFXLHFCQUFxQjtFQUVoQyxJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSxpQkFBaUI7SUFDNUMsUUFBUTtJQUNSLFNBQVMsRUFDUCxnQkFBZ0IsbUJBQ2xCO0lBQ0EsTUFBTSxLQUFLLFVBQVU7S0FDbkIsY0FBYyxRQUFRO0tBQ3RCLGVBQWUsUUFBUTtLQUN2QixRQUFRLFFBQVE7S0FDaEIsU0FBUyxRQUFRLFFBQVE7S0FDekIsYUFBYSxRQUFRO0tBQ3JCLGFBQWEsR0FBRyxRQUFRLEtBQUs7SUFDL0IsQ0FBQztHQUNILENBQUM7R0FFRCxJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLE1BQU0sSUFBSSxNQUFNLDhCQUE4QjtHQUNoRDtHQUVBLE1BQU0sZUFBZSxNQUFNLFNBQVMsS0FBSztHQUV6QyxvQkFBb0IsWUFBWTtHQUVoQyxXQUFXLEVBQUU7R0FFYixNQUFNLGFBQWE7RUFDckIsU0FBUyxPQUFPO0dBQ2QsV0FBVyxNQUFNLE9BQU87RUFDMUI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUlFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQ2hCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxVQUFEO09BQ0UsV0FBVTtPQUNWLGVBQWUsU0FBUyxNQUFNO2lCQUZoQyxDQUlFLHdCQUFDLE9BQUQ7UUFDRSxLQUFJO1FBQ0osS0FBSTtPQUNMOzs7O2lCQUVELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7a0JBQ25CLHdCQUFDLFNBQUQsWUFBTyxhQUFpQjs7OztnQkFDckI7Ozs7O2VBQ0M7Ozs7OztNQUVSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBRUUsd0JBQUMsVUFBRDtTQUFRLGVBQWUsU0FBUyxNQUFNO21CQUFHO1FBRWpDOzs7OztRQUVSLHdCQUFDLFVBQUQ7U0FBUSxlQUFlLFNBQVMsVUFBVTttQkFBRztRQUVyQzs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQVEsZUFBZSxTQUFTLFNBQVM7bUJBQUc7UUFFcEM7Ozs7O1FBRVIsd0JBQUMsVUFBRDtTQUFRLGVBQWUsU0FBUyxVQUFVO21CQUFHO1FBRXJDOzs7OztRQUVSLHdCQUFDLFVBQUQ7U0FBUSxlQUFlLFNBQVMsU0FBUzttQkFBRztRQUVwQzs7Ozs7T0FFTDs7Ozs7O01BRUwsd0JBQUMsVUFBRDtPQUNFLFdBQVU7T0FDVixlQUFlLFNBQVMsU0FBUztpQkFDbEM7TUFFTzs7Ozs7TUFFUix3QkFBQyxVQUFEO09BQVEsV0FBVTtpQkFBYztNQUV4Qjs7Ozs7S0FFTDs7Ozs7O0dBQ0M7Ozs7O0dBSVAsU0FBUyxVQUNSLHdCQUFDLFFBQUQsYUFFRSx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUVqQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWE7TUFFdkI7Ozs7O01BRU4sd0JBQUMsTUFBRDtPQUFJO09BRUYsd0JBQUMsTUFBRCxDQUFLOzs7OztPQUNMLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7OztNQUNsQjs7Ozs7TUFFSix3QkFBQyxLQUFELFlBQUcsaURBRUE7Ozs7O01BRUgsd0JBQUMsVUFBRDtPQUNFLFdBQVU7T0FDVixlQUFlLFNBQVMsU0FBUztpQkFDbEM7TUFFTzs7Ozs7S0FFTDs7Ozs7O0dBRUU7Ozs7YUFFVCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQjtLQUVFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFnQjtLQUUxQjs7Ozs7S0FFTix3QkFBQyxNQUFELFlBQUksbUNBRUE7Ozs7O0tBRUosd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FFRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7OztTQUNkLHdCQUFDLE1BQUQsWUFBSSxrQkFBbUI7Ozs7O1NBQ3ZCLHdCQUFDLEtBQUQsWUFBRyxzQ0FFQTs7Ozs7UUFDQTs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFELFlBQU0sS0FBUTs7Ozs7U0FDZCx3QkFBQyxNQUFELFlBQUksV0FBWTs7Ozs7U0FDaEIsd0JBQUMsS0FBRCxZQUFHLHdDQUVBOzs7OztRQUNBOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7OztTQUNkLHdCQUFDLE1BQUQsWUFBSSxXQUFZOzs7OztTQUNoQix3QkFBQyxLQUFELFlBQUcsc0NBRUE7Ozs7O1FBQ0E7Ozs7OztNQUVGOzs7Ozs7SUFFRTs7Ozs7V0FFTDs7Ozs7R0FLUCxTQUFTLGNBQ1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEI7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFnQjtPQUUxQjs7Ozs7T0FFTix3QkFBQyxNQUFELFlBQUksZ0JBQWlCOzs7OztPQUVyQix3QkFBQyxLQUFELFlBQUcsMkNBRUE7Ozs7O01BQ0E7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUVaLFNBQVMsS0FBSyxZQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBRUUsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQWlDLEtBQzdCLFFBQVEsRUFDTjs7Ozs7O1FBRU4sd0JBQUMsTUFBRCxZQUFLLFFBQVEsS0FBUzs7Ozs7UUFFdEIsd0JBQUMsS0FBRCxZQUFJLFFBQVEsWUFBZTs7Ozs7UUFFM0Isd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU8sUUFBUSxTQUFlOzs7O21CQUM5Qix3QkFBQyxVQUFELFlBQVMsUUFBUSxNQUFjOzs7O2lCQUM1Qjs7Ozs7O09BRUY7U0Fmb0MsUUFBUTs7OzthQWU1QyxDQUNOO0tBRUU7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBRWIsd0JBQUMsVUFBRDtPQUNFLFdBQVU7T0FDVixlQUFlLFNBQVMsU0FBUztpQkFDbEM7TUFFTzs7Ozs7S0FFTDs7Ozs7SUFFRDs7Ozs7O0dBS1AsU0FBUyxhQUNSLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBRWIsbUJBSUM7S0FBQzs7S0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FFRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZTtPQUV6Qjs7Ozs7T0FFTCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0I7T0FFMUI7Ozs7O09BRU4sd0JBQUMsTUFBRCxZQUFJLHlCQUEwQjs7Ozs7T0FFOUIsd0JBQUMsS0FBRCxZQUFHLG1DQUVBOzs7OztPQUVILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBRUUsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OzttQkFDdEIsd0JBQUMsVUFBRCxZQUNHLGlCQUFpQixRQUNaOzs7O2lCQUNMOzs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFELFlBQU0sWUFBZTs7OzttQkFDckIsd0JBQUMsVUFBRCxZQUNHLGlCQUFpQixPQUNaOzs7O2lCQUNMOzs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFELFlBQU0sUUFBVzs7OzttQkFDakIsd0JBQUMsVUFBRCxZQUNHLGlCQUFpQixZQUNaOzs7O2lCQUNMOzs7OztTQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFELFlBQU0sTUFBUzs7OzttQkFDZix3QkFBQyxVQUFELFlBQ0csaUJBQWlCLFlBQVksVUFBVSxHQUFHLENBQUMsRUFDdEM7Ozs7aUJBQ0w7Ozs7O1FBRUY7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBRUUsd0JBQUMsUUFBRCxZQUFNLGlCQUFvQjs7Ozs7U0FFMUIsd0JBQUMsVUFBRCxZQUNHLGlCQUFpQixZQUNaOzs7OztTQUVSLHdCQUFDLEtBQUQsWUFDRyxpQkFBaUIsWUFBWSxVQUFVLEdBQUcsQ0FBQyxFQUMzQzs7Ozs7UUFFQTs7Ozs7O09BRUwsd0JBQUMsVUFBRDtRQUNFLFdBQVU7UUFDVixlQUFlLFNBQVMsVUFBVTtrQkFDbkM7T0FFTzs7Ozs7TUFFTDs7Ozs7Ozs7Ozs7O0lBTUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBRUUsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWdCO1FBRTFCOzs7OztRQUVOLHdCQUFDLE1BQUQsWUFBSSxXQUFZOzs7OztRQUVoQix3QkFBQyxLQUFELFlBQUcsc0NBRUE7Ozs7O09BRUE7Ozs7OztNQUlMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBRUUsd0JBQUMsT0FBRDtTQUFLLFdBQVcsUUFBUSxRQUFRLElBQUksV0FBVzttQkFBL0MsQ0FDRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OzttQkFDYix3QkFBQyxLQUFELFlBQUcsYUFBYTs7OztpQkFDYjs7Ozs7O1FBRUwsd0JBQUMsT0FBRCxFQUFLLFdBQVUsWUFBYTs7Ozs7UUFFNUIsd0JBQUMsT0FBRDtTQUFLLFdBQVcsUUFBUSxRQUFRLElBQUksV0FBVzttQkFBL0MsQ0FDRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OzttQkFDYix3QkFBQyxLQUFELFlBQUcsWUFBWTs7OztpQkFDWjs7Ozs7O1FBRUwsd0JBQUMsT0FBRCxFQUFLLFdBQVUsWUFBYTs7Ozs7UUFFNUIsd0JBQUMsT0FBRDtTQUFLLFdBQVcsUUFBUSxRQUFRLElBQUksV0FBVzttQkFBL0MsQ0FDRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OzttQkFDYix3QkFBQyxLQUFELFlBQUcsTUFBTTs7OztpQkFDTjs7Ozs7O1FBRUwsd0JBQUMsT0FBRCxFQUFLLFdBQVUsWUFBYTs7Ozs7UUFFNUIsd0JBQUMsT0FBRDtTQUFLLFdBQVcsUUFBUSxRQUFRLElBQUksV0FBVzttQkFBL0MsQ0FDRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OzttQkFDYix3QkFBQyxLQUFELFlBQUcsV0FBVzs7OztpQkFDWDs7Ozs7O09BRUY7Ozs7OztNQUVKLFdBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1o7TUFDRTs7Ozs7TUFLTixTQUFTLEtBQ1Isd0JBQUMsV0FBRDtPQUFTLFdBQVU7aUJBQW5CO1FBRUUsd0JBQUMsTUFBRCxZQUFJLGtCQUFtQjs7Ozs7UUFFdkIsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQW1CO1FBRTdCOzs7OztRQUVILHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUVaLFNBQVMsS0FBSyxZQUViLHdCQUFDLFVBQUQ7VUFDRSxXQUFXLGdCQUNULFFBQVEsU0FBUyxPQUFPLFFBQVEsS0FDNUIsYUFDQTtVQUdOLGVBQWUsY0FBYyxPQUFPO29CQVB0QyxDQVVFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBRUUsd0JBQUMsTUFBRCxZQUFLLFFBQVEsS0FBUzs7Ozs7WUFFdEIsd0JBQUMsS0FBRCxZQUFJLFFBQVEsWUFBZTs7Ozs7WUFFM0Isd0JBQUMsUUFBRCxZQUNHLFFBQVEsU0FDTDs7Ozs7V0FFSDs7Ozs7b0JBRUwsd0JBQUMsVUFBRCxZQUNHLFFBQVEsTUFDSDs7OztrQkFFRjtZQXBCRCxRQUFROzs7O2dCQW9CUCxDQUVUO1FBRUU7Ozs7O09BRUU7Ozs7OztNQUtWLFNBQVMsS0FDUix3QkFBQyxXQUFEO09BQVMsV0FBVTtpQkFBbkI7UUFFRSx3QkFBQyxNQUFELFlBQUksaUJBQWtCOzs7OztRQUV0Qix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBbUI7UUFFN0I7Ozs7O1FBRUgsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBRVosUUFBUSxLQUFLLFdBRVosd0JBQUMsVUFBRDtVQUNFLFdBQVcsZUFDVCxRQUFRLFdBQVcsU0FDZixhQUNBO1VBR04sZUFBZSxhQUFhLE1BQU07b0JBUHBDLENBVUUsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1osT0FBTyxPQUFPLENBQUM7VUFDYjs7OztvQkFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRCxZQUFLLE9BQVc7Ozs7b0JBQ2hCLHdCQUFDLEtBQUQsWUFBRyxZQUFZOzs7O2tCQUNaOzs7O2tCQUVDO1lBYkQ7Ozs7Z0JBYUMsQ0FFVDtRQUVFOzs7OztPQUVFOzs7Ozs7TUFLVixTQUFTLEtBQ1Isd0JBQUMsV0FBRDtPQUFTLFdBQVU7aUJBQW5CO1FBRUUsd0JBQUMsTUFBRCxZQUFJLHFCQUFzQjs7Ozs7UUFFMUIsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQW1CO1FBRTdCOzs7OztRQUVILHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUVaLFNBQVMsS0FBSyxRQUViLHdCQUFDLE9BQUQ7VUFDRSxXQUFXLGNBQ1QsUUFBUSxTQUFTLElBQUksT0FDakIsaUJBQ0E7b0JBSlIsQ0FTRSx3QkFBQyxVQUFEO1dBQ3RCLFdBQVU7V0FDVixlQUFhLE9BQU8sSUFBSTtXQUN4QixlQUFlLFdBQVcsSUFBSSxJQUFJO3FCQUhaO1lBS0Usd0JBQUMsUUFBRCxZQUNHLElBQUksUUFDRDs7Ozs7WUFFTix3QkFBQyxVQUFELFlBQ0csSUFBSSxVQUNDOzs7OztZQUVSLHdCQUFDLFNBQUQsWUFDRyxJQUFJLE1BQ0E7Ozs7O1dBQ0Q7Ozs7O29CQUVSLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUVaLE1BQU0sS0FBSyxTQUFTO1lBRW5CLE1BQU0sU0FBUyxhQUNiLElBQUksTUFDSixJQUNGO1lBRUEsTUFBTSxXQUNKLFFBQVEsU0FBUyxJQUFJLFFBQ3JCLFFBQVEsU0FBUztZQUVuQixPQUNFLHdCQUFDLFVBQUQ7YUFFNUIsVUFBVTthQUNWLGVBQWEsUUFBUSxJQUFJLEtBQUssR0FBRzthQUNqQyxXQUFXLGFBQWEsV0FBVyxhQUFhLEdBQUcsR0FBRyxTQUFTLFdBQVc7YUFDMUUsZUFBZTtjQUNiLFdBQVc7ZUFDVCxHQUFHO2VBQ0gsTUFBTSxJQUFJO2VBQ1Y7Y0FDRixDQUFDO2FBQ0g7dUJBRUMsU0FBUyxVQUFVO1lBQ2QsR0FiRDs7OzttQkFhQztXQUVrQixDQUFDO1VBRUU7Ozs7a0JBRUY7WUF2REUsSUFBSTs7OztnQkF1RE4sQ0FFTjtRQUVFOzs7OztPQUVFOzs7Ozs7TUFLVixTQUFTLEtBQ1Isd0JBQUMsV0FBRDtPQUFTLFdBQVU7aUJBQW5CO1FBRUUsd0JBQUMsTUFBRCxZQUFJLG1CQUFvQjs7Ozs7UUFFeEIsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQW1CO1FBRTdCOzs7OztRQUVILHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBRUUsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztvQkFDdEIsd0JBQUMsVUFBRCxZQUNHLFFBQVEsU0FBUyxLQUNaOzs7O2tCQUNMOzs7OztVQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFELFlBQU0sWUFBZTs7OztvQkFDckIsd0JBQUMsVUFBRCxZQUNHLFFBQVEsT0FDSDs7OztrQkFDTDs7Ozs7VUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7b0JBQ2pCLHdCQUFDLFVBQUQsWUFDRyxRQUFRLEtBQ0g7Ozs7a0JBQ0w7Ozs7O1VBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQsWUFBTSxNQUFTOzs7O29CQUNmLHdCQUFDLFVBQUQsWUFDRyxRQUFRLEtBQ0g7Ozs7a0JBQ0w7Ozs7O1VBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7O29CQUNoQix3QkFBQyxVQUFELFlBQ0csUUFBUSxTQUFTLE1BQ1o7Ozs7a0JBQ0w7Ozs7O1NBRUY7Ozs7OztRQUVMLHdCQUFDLFFBQUQ7U0FDRSxJQUFHO1NBQ0gsVUFBVTttQkFGWjtVQUtFLHdCQUFDLFNBQUQsWUFBTyxPQUFXOzs7OztVQUVsQix3QkFBQyxTQUFEO1dBQ0UsV0FBVTtXQUNWLE1BQUs7V0FDTCxNQUFLO1dBQ0wsYUFBWTtXQUNaLE9BQU8sUUFBUTtXQUNmLFVBQVU7V0FDVjtVQUNEOzs7OztVQUVELHdCQUFDLFNBQUQsWUFBTyxTQUFhOzs7OztVQUVwQix3QkFBQyxTQUFEO1dBQ0UsV0FBVTtXQUNWLE1BQUs7V0FDTCxNQUFLO1dBQ0wsYUFBWTtXQUNaLE9BQU8sUUFBUTtXQUNmLFVBQVU7V0FDVjtVQUNEOzs7OztTQUVHOzs7Ozs7T0FFQzs7Ozs7O01BS1gsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FFRyxPQUFPLElBQ04sd0JBQUMsVUFBRDtRQUNFLFdBQVU7UUFDVixTQUFTO2tCQUNWO09BRU87Ozs7a0JBRVIsd0JBQUMsT0FBRCxDQUFNOzs7O2lCQUdQLE9BQU8sSUFDTix3QkFBQyxVQUFEO1FBQ0UsV0FBVTtRQUNWLFNBQVM7a0JBQ1Y7T0FFTzs7OztrQkFFUix3QkFBQyxVQUFEO1FBQ0UsV0FBVTtRQUNWLE1BQUs7UUFDTCxNQUFLO2tCQUNOO09BRU87Ozs7ZUFHUDs7Ozs7O0tBRUY7Ozs7OztHQUdIOzs7OztHQUtQLFNBQVMsY0FDUix3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBZ0I7TUFFMUI7Ozs7O01BRU4sd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7Ozs7TUFFdEIsd0JBQUMsS0FBRCxZQUFHLGdDQUVBOzs7OztLQUVBOzs7OztjQUVKLFNBQVMsV0FBVyxJQUVuQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsTUFBRCxZQUFJLHNCQUF1Qjs7Ozs7TUFFM0Isd0JBQUMsS0FBRCxZQUFHLDhDQUVBOzs7OztNQUVILHdCQUFDLFVBQUQ7T0FDRSxXQUFVO09BQ1YsZUFBZSxTQUFTLFNBQVM7aUJBQ2xDO01BRU87Ozs7O0tBQ0w7Ozs7O2VBSUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFFWixTQUFTLEtBQUssU0FFYix3QkFBQyxPQUFEO01BQ0UsV0FBVTtnQkFEWixDQUtFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBRUUsd0JBQUMsUUFBRCxZQUNHLEtBQUssWUFDRjs7OztpQkFFTix3QkFBQyxVQUFELFlBQ0csS0FBSyxZQUFZLFVBQVUsR0FBRyxDQUFDLEVBQzFCOzs7O2VBRUw7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBRUUsd0JBQUMsTUFBRCxZQUFLLEtBQUssUUFBWTs7Ozs7UUFFdEIsd0JBQUMsS0FBRCxhQUFHLGVBQ1csS0FBSyxNQUNoQjs7Ozs7UUFFSCx3QkFBQyxLQUFELFlBQ0csS0FBSyxhQUNMOzs7OztPQUVBOzs7OztjQUVGO1FBN0JFLEtBQUs7Ozs7WUE2QlAsQ0FFTjtJQUVFOzs7O1lBSUg7Ozs7OztHQUtQLFNBQVMsYUFDUix3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBZ0I7TUFFMUI7Ozs7O01BRU4sd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7OztNQUVwQix3QkFBQyxLQUFELFlBQUcsd0JBRUE7Ozs7O0tBRUE7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRCxZQUFNLFNBQVk7Ozs7O1FBQ2xCLHdCQUFDLE1BQUQsWUFBSSxZQUFhOzs7OztRQUNqQix3QkFBQyxLQUFELFlBQUcscUNBRUE7Ozs7O09BQ0E7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7O1FBQ25CLHdCQUFDLE1BQUQsWUFBSSxlQUFnQjs7Ozs7UUFDcEIsd0JBQUMsS0FBRCxZQUFHLGtDQUVBOzs7OztPQUNBOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7OztRQUNsQix3QkFBQyxNQUFELFlBQUksNEJBQTZCOzs7OztRQUNqQyx3QkFBQyxLQUFELFlBQUcsNkJBRUE7Ozs7O09BQ0E7Ozs7OztLQUVGOzs7OztZQUVEOzs7Ozs7R0FHUix3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FBNkIsV0FFM0Isd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O2FBQ25COzs7OztjQUVMLHdCQUFDLEtBQUQsWUFBRyw0QkFFQTs7OztZQUVHOzs7Ozs7RUFFTDs7Ozs7O0FBRVQ7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgJy4vQXBwLmNzcydcblxuY29uc3Qgc2VydmljZXMgPSBbXG4gIHtcbiAgICBpZDogMSxcbiAgICBuYW1lOiAnSGFpcmN1dCcsXG4gICAgZGVzY3JpcHRpb246ICdLbGFzc2lzayBrbGlwcG5pbmcnLFxuICAgIHByaWNlOiAnMzUwIGtyJyxcbiAgICBkdXJhdGlvbjogJzMwIG1pbicsXG4gIH0sXG4gIHtcbiAgICBpZDogMixcbiAgICBuYW1lOiAnQmVhcmQgVHJpbScsXG4gICAgZGVzY3JpcHRpb246ICdUcmltbmluZyBvY2ggZm9ybW5pbmcgYXYgc2vDpGdnJyxcbiAgICBwcmljZTogJzI1MCBrcicsXG4gICAgZHVyYXRpb246ICcyMCBtaW4nLFxuICB9LFxuICB7XG4gICAgaWQ6IDMsXG4gICAgbmFtZTogJ0hhaXJjdXQgJiBCZWFyZCcsXG4gICAgZGVzY3JpcHRpb246ICdLbGlwcG5pbmcgKyBza8OkZ2cnLFxuICAgIHByaWNlOiAnNTAwIGtyJyxcbiAgICBkdXJhdGlvbjogJzQ1IG1pbicsXG4gIH0sXG5dXG5cbmNvbnN0IGJhcmJlcnMgPSBbJ0FobWVkJywgJ01vaGFtbWVkJywgJ0FsaSddXG5cbmNvbnN0IHRpbWVzID0gW1xuICAnMTA6MDAnLFxuICAnMTE6MDAnLFxuICAnMTI6MDAnLFxuICAnMTM6MDAnLFxuICAnMTQ6MDAnLFxuICAnMTU6MDAnLFxuICAnMTY6MDAnLFxuICAnMTc6MDAnLFxuXVxuXG5mdW5jdGlvbiBnZXRXZWVrRGF5cygpIHtcbiAgY29uc3QgZGF5cyA9IFtdXG5cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCA3OyBpKyspIHtcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoKVxuICAgIGRhdGUuc2V0SG91cnMoMCwgMCwgMCwgMClcbiAgICBkYXRlLnNldERhdGUoZGF0ZS5nZXREYXRlKCkgKyBpKVxuXG4gICAgY29uc3QgZGF0ZVN0cmluZyA9XG4gICAgICBgJHtkYXRlLmdldEZ1bGxZZWFyKCl9LWAgK1xuICAgICAgYCR7U3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJyl9LWAgK1xuICAgICAgYCR7U3RyaW5nKGRhdGUuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCAnMCcpfWBcblxuICAgIGRheXMucHVzaCh7XG4gICAgICBkYXRlOiBkYXRlU3RyaW5nLFxuICAgICAgZGF5TmFtZTogZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoJ3N2LVNFJywge1xuICAgICAgICB3ZWVrZGF5OiAnc2hvcnQnLFxuICAgICAgfSksXG4gICAgICBkYXlOdW1iZXI6IGRhdGUuZ2V0RGF0ZSgpLFxuICAgICAgbW9udGg6IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCdzdi1TRScsIHtcbiAgICAgICAgbW9udGg6ICdzaG9ydCcsXG4gICAgICB9KSxcbiAgICB9KVxuICB9XG5cbiAgcmV0dXJuIGRheXNcbn1cblxuZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBbcGFnZSwgc2V0UGFnZV0gPSB1c2VTdGF0ZSgnaG9tZScpXG4gIGNvbnN0IFtzdGVwLCBzZXRTdGVwXSA9IHVzZVN0YXRlKDEpXG5cbiAgY29uc3QgW2Jvb2tpbmdzLCBzZXRCb29raW5nc10gPSB1c2VTdGF0ZShbXSlcblxuICBjb25zdCBbYm9va2luZywgc2V0Qm9va2luZ10gPSB1c2VTdGF0ZSh7XG4gICAgc2VydmljZTogbnVsbCxcbiAgICBiYXJiZXI6ICcnLFxuICAgIGRhdGU6ICcnLFxuICAgIHRpbWU6ICcnLFxuICAgIGN1c3RvbWVyTmFtZTogJycsXG4gICAgY3VzdG9tZXJFbWFpbDogJycsXG4gIH0pXG5cbiAgY29uc3QgW2NvbmZpcm1lZEJvb2tpbmcsIHNldENvbmZpcm1lZEJvb2tpbmddID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3Qgd2Vla0RheXMgPSBnZXRXZWVrRGF5cygpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2FkQm9va2luZ3MoKVxuICB9LCBbXSlcblxuICBjb25zdCBsb2FkQm9va2luZ3MgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJy9hcGkvYm9va2luZ3MnKVxuXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignS3VuZGUgaW50ZSBow6RtdGEgYm9rbmluZ2FyJylcbiAgICAgIH1cblxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKVxuICAgICAgc2V0Qm9va2luZ3MoZGF0YSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnJvcilcbiAgICB9XG4gIH1cblxuICBjb25zdCBnb1RvUGFnZSA9IChuZXdQYWdlKSA9PiB7XG4gICAgc2V0UGFnZShuZXdQYWdlKVxuICAgIHNldE1lc3NhZ2UoJycpXG5cbiAgICBpZiAobmV3UGFnZSA9PT0gJ2Jvb2tpbmcnKSB7XG4gICAgICBzZXRTdGVwKDEpXG4gICAgICBzZXRDb25maXJtZWRCb29raW5nKG51bGwpXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc2VsZWN0U2VydmljZSA9IChzZXJ2aWNlKSA9PiB7XG4gICAgc2V0Qm9va2luZyh7XG4gICAgICAuLi5ib29raW5nLFxuICAgICAgc2VydmljZSxcbiAgICB9KVxuICB9XG5cbiAgY29uc3Qgc2VsZWN0QmFyYmVyID0gKGJhcmJlcikgPT4ge1xuICAgIHNldEJvb2tpbmcoe1xuICAgICAgLi4uYm9va2luZyxcbiAgICAgIGJhcmJlcixcbiAgICB9KVxuICB9XG5cbiAgY29uc3Qgc2VsZWN0RGF0ZSA9IChkYXRlKSA9PiB7XG4gICAgc2V0Qm9va2luZyh7XG4gICAgICAuLi5ib29raW5nLFxuICAgICAgZGF0ZSxcbiAgICAgIHRpbWU6ICcnLFxuICAgIH0pXG4gIH1cblxuICBjb25zdCBzZWxlY3RUaW1lID0gKHRpbWUpID0+IHtcbiAgICBzZXRCb29raW5nKHtcbiAgICAgIC4uLmJvb2tpbmcsXG4gICAgICB0aW1lLFxuICAgIH0pXG4gIH1cblxuICBjb25zdCBpc1RpbWVCb29rZWQgPSAoZGF0ZSwgdGltZSkgPT4ge1xuICAgIHJldHVybiBib29raW5ncy5zb21lKFxuICAgICAgKGl0ZW0pID0+XG4gICAgICAgIGl0ZW0uYm9va2luZ0RhdGUgPT09IGRhdGUgJiZcbiAgICAgICAgaXRlbS5ib29raW5nVGltZS5zdGFydHNXaXRoKHRpbWUpXG4gICAgKVxuICB9XG5cbiAgY29uc3QgY29udGludWVUb05leHRTdGVwID0gKCkgPT4ge1xuICAgIGlmIChzdGVwID09PSAxICYmICFib29raW5nLnNlcnZpY2UpIHtcbiAgICAgIHNldE1lc3NhZ2UoJ1bDpGxqIGVuIGJlaGFuZGxpbmcgZsO2cnN0LicpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBpZiAoc3RlcCA9PT0gMiAmJiAhYm9va2luZy5iYXJiZXIpIHtcbiAgICAgIHNldE1lc3NhZ2UoJ1bDpGxqIGVuIGJhcmJlcmFyZSBmw7Zyc3QuJylcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGlmIChzdGVwID09PSAzICYmICghYm9va2luZy5kYXRlIHx8ICFib29raW5nLnRpbWUpKSB7XG4gICAgICBzZXRNZXNzYWdlKCdWw6RsaiBkYXR1bSBvY2ggdGlkIGbDtnJzdC4nKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgc2V0TWVzc2FnZSgnJylcbiAgICBzZXRTdGVwKHN0ZXAgKyAxKVxuICB9XG5cbiAgY29uc3QgZ29CYWNrID0gKCkgPT4ge1xuICAgIGlmIChzdGVwID4gMSkge1xuICAgICAgc2V0TWVzc2FnZSgnJylcbiAgICAgIHNldFN0ZXAoc3RlcCAtIDEpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZXZlbnQpID0+IHtcbiAgICBzZXRCb29raW5nKHtcbiAgICAgIC4uLmJvb2tpbmcsXG4gICAgICBbZXZlbnQudGFyZ2V0Lm5hbWVdOiBldmVudC50YXJnZXQudmFsdWUsXG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcblxuICAgIHNldE1lc3NhZ2UoJ0Jva25pbmdlbiBzcGFyYXMuLi4nKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJy9hcGkvYm9va2luZ3MnLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGN1c3RvbWVyTmFtZTogYm9va2luZy5jdXN0b21lck5hbWUsXG4gICAgICAgICAgY3VzdG9tZXJFbWFpbDogYm9va2luZy5jdXN0b21lckVtYWlsLFxuICAgICAgICAgIGJhcmJlcjogYm9va2luZy5iYXJiZXIsXG4gICAgICAgICAgc2VydmljZTogYm9va2luZy5zZXJ2aWNlLm5hbWUsXG4gICAgICAgICAgYm9va2luZ0RhdGU6IGJvb2tpbmcuZGF0ZSxcbiAgICAgICAgICBib29raW5nVGltZTogYCR7Ym9va2luZy50aW1lfTowMGAsXG4gICAgICAgIH0pLFxuICAgICAgfSlcblxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Jva25pbmdlbiBrdW5kZSBpbnRlIHNwYXJhcy4nKVxuICAgICAgfVxuXG4gICAgICBjb25zdCBzYXZlZEJvb2tpbmcgPSBhd2FpdCByZXNwb25zZS5qc29uKClcblxuICAgICAgc2V0Q29uZmlybWVkQm9va2luZyhzYXZlZEJvb2tpbmcpXG5cbiAgICAgIHNldE1lc3NhZ2UoJycpXG5cbiAgICAgIGF3YWl0IGxvYWRCb29raW5ncygpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldE1lc3NhZ2UoZXJyb3IubWVzc2FnZSlcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXBwXCI+XG5cbiAgICAgIHsvKiBIRUFERVIgKi99XG5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwic2l0ZS1oZWFkZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXItaW5uZXJcIj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJyYW5kXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGdvVG9QYWdlKCdob21lJyl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICBzcmM9XCIvZGlhbW9uZC1sb2dvLmpwZ1wiXG4gICAgICAgICAgICAgIGFsdD1cIkRpYW1vbmQgQmFyYmVyc2hvcFwiXG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyYW5kLXRleHRcIj5cbiAgICAgICAgICAgICAgPHNwYW4+RElBTU9ORDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNtYWxsPkJBUkJFUlNIT1A8L3NtYWxsPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cIm1haW4tbmF2XCI+XG5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gZ29Ub1BhZ2UoJ2hvbWUnKX0+XG4gICAgICAgICAgICAgIEhlbVxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gZ29Ub1BhZ2UoJ3NlcnZpY2VzJyl9PlxuICAgICAgICAgICAgICBUasOkbnN0ZXJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGdvVG9QYWdlKCdib29raW5nJyl9PlxuICAgICAgICAgICAgICBCb2thIHRpZFxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gZ29Ub1BhZ2UoJ2Jvb2tpbmdzJyl9PlxuICAgICAgICAgICAgICBNaW5hIGJva25pbmdhclxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gZ29Ub1BhZ2UoJ2NvbnRhY3QnKX0+XG4gICAgICAgICAgICAgIEtvbnRha3RcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPC9uYXY+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoZWFkZXItYm9vay1idXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZ29Ub1BhZ2UoJ2Jvb2tpbmcnKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBCb2thIHRpZFxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJtb2JpbGUtbWVudVwiPlxuICAgICAgICAgICAg4piwXG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgey8qIEhPTUUgKi99XG5cbiAgICAgIHtwYWdlID09PSAnaG9tZScgJiYgKFxuICAgICAgICA8bWFpbj5cblxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImhlcm9cIj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLWNvbnRlbnRcIj5cblxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoZXJvLWxhYmVsXCI+XG4gICAgICAgICAgICAgICAgRElBTU9ORCBCQVJCRVJTSE9QXG4gICAgICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgICAgICA8aDE+XG4gICAgICAgICAgICAgICAgRGluIHN0aWwuXG4gICAgICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+RGluIHRpZC48L3NwYW4+XG4gICAgICAgICAgICAgIDwvaDE+XG5cbiAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgUHJvZmVzc2lvbmVsbCBiYXJiZXJpbmcgbWVkIHBlcnNvbmxpZyBzZXJ2aWNlLlxuICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhlcm8tYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBnb1RvUGFnZSgnYm9va2luZycpfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQm9rYSBkaW4gdGlkXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImhvbWUtc2VjdGlvblwiPlxuXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLWxhYmVsXCI+XG4gICAgICAgICAgICAgIERJQU1PTkQgRVhQRVJJRU5DRVxuICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICA8aDI+XG4gICAgICAgICAgICAgIEVuIGVua2VsIHbDpGcgdGlsbCBkaW4gbsOkc3RhIGxvb2tcbiAgICAgICAgICAgIDwvaDI+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZS1ncmlkXCI+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlLWNhcmRcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj4wMTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8aDM+VsOkbGogYmVoYW5kbGluZzwvaDM+XG4gICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICBWw6RsaiBkZW4gYmVoYW5kbGluZyBzb20gcGFzc2FyIGRpZy5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZS1jYXJkXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+MDI8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGgzPlbDpGxqIHRpZDwvaDM+XG4gICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICBTZSBoZWxhIHZlY2thbiBvY2ggdsOkbGogZW4gbGVkaWcgdGlkLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlLWNhcmRcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj4wMzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8aDM+QmVrcsOkZnRhPC9oMz5cbiAgICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICAgIEZ5bGwgaSBkaW5hIHVwcGdpZnRlciBvY2ggYmVrcsOkZnRhLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgIDwvbWFpbj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBTRVJWSUNFUyAqL31cblxuICAgICAge3BhZ2UgPT09ICdzZXJ2aWNlcycgJiYgKFxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJwYWdlLWNvbnRhaW5lclwiPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLWhlYWRpbmdcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNlY3Rpb24tbGFiZWxcIj5cbiAgICAgICAgICAgICAgRElBTU9ORCBCQVJCRVJTSE9QXG4gICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgIDxoMT5Ww6VyYSB0asOkbnN0ZXI8L2gxPlxuXG4gICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgVsOkbGogZGVuIGJlaGFuZGxpbmcgc29tIHBhc3NhciBkaW4gc3RpbC5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VydmljZXMtcGFnZS1ncmlkXCI+XG5cbiAgICAgICAgICAgIHtzZXJ2aWNlcy5tYXAoKHNlcnZpY2UpID0+IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsYXJnZS1zZXJ2aWNlLWNhcmRcIiBrZXk9e3NlcnZpY2UuaWR9PlxuXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2VydmljZS1udW1iZXJcIj5cbiAgICAgICAgICAgICAgICAgIDB7c2VydmljZS5pZH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgICAgICA8aDI+e3NlcnZpY2UubmFtZX08L2gyPlxuXG4gICAgICAgICAgICAgICAgPHA+e3NlcnZpY2UuZGVzY3JpcHRpb259PC9wPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXJ2aWNlLWJvdHRvbVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e3NlcnZpY2UuZHVyYXRpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz57c2VydmljZS5wcmljZX08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuXG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNlbnRlci1idXR0b25cIj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoZXJvLWJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGdvVG9QYWdlKCdib29raW5nJyl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEJva2EgYmVoYW5kbGluZ1xuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L21haW4+XG4gICAgICApfVxuXG4gICAgICB7LyogQk9PS0lORyAqL31cblxuICAgICAge3BhZ2UgPT09ICdib29raW5nJyAmJiAoXG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImJvb2tpbmctY29udGFpbmVyXCI+XG5cbiAgICAgICAgICB7Y29uZmlybWVkQm9va2luZyA/IChcblxuICAgICAgICAgICAgLyogQ09ORklSTUFUSU9OICovXG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29uZmlybWF0aW9uLXBhZ2VcIj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Y2Nlc3MtaWNvblwiPlxuICAgICAgICAgICAgICAgIOKck1xuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLWxhYmVsXCI+XG4gICAgICAgICAgICAgICAgRElBTU9ORCBCQVJCRVJTSE9QXG4gICAgICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgICAgICA8aDE+Qm9rbmluZ2VuIMOkciBiZWtyw6RmdGFkPC9oMT5cblxuICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICBWaSBzZXIgZnJhbSBlbW90IGF0dCB0csOkZmZhIGRpZy5cbiAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29uZmlybWVkLWNhcmRcIj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5CZWhhbmRsaW5nPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAge2NvbmZpcm1lZEJvb2tpbmcuc2VydmljZX1cbiAgICAgICAgICAgICAgICAgIDwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkJhcmJlcmFyZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgIHtjb25maXJtZWRCb29raW5nLmJhcmJlcn1cbiAgICAgICAgICAgICAgICAgIDwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkRhdHVtPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAge2NvbmZpcm1lZEJvb2tpbmcuYm9va2luZ0RhdGV9XG4gICAgICAgICAgICAgICAgICA8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5UaWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICB7Y29uZmlybWVkQm9va2luZy5ib29raW5nVGltZS5zdWJzdHJpbmcoMCwgNSl9XG4gICAgICAgICAgICAgICAgICA8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbmZpcm1hdGlvbi10aW1lXCI+XG5cbiAgICAgICAgICAgICAgICA8c3Bhbj5ESU4gQk9LQURFIFRJRDwvc3Bhbj5cblxuICAgICAgICAgICAgICAgIDxzdHJvbmc+XG4gICAgICAgICAgICAgICAgICB7Y29uZmlybWVkQm9va2luZy5ib29raW5nRGF0ZX1cbiAgICAgICAgICAgICAgICA8L3N0cm9uZz5cblxuICAgICAgICAgICAgICAgIDxiPlxuICAgICAgICAgICAgICAgICAge2NvbmZpcm1lZEJvb2tpbmcuYm9va2luZ1RpbWUuc3Vic3RyaW5nKDAsIDUpfVxuICAgICAgICAgICAgICAgIDwvYj5cblxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29udGludWUtYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBnb1RvUGFnZSgnYm9va2luZ3MnKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFZpc2EgbWluYSBib2tuaW5nYXJcbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgKSA6IChcblxuICAgICAgICAgICAgLyogQk9PS0lORyBGTE9XICovXG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1jYXJkXCI+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib29raW5nLWhlYWRlclwiPlxuXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2VjdGlvbi1sYWJlbFwiPlxuICAgICAgICAgICAgICAgICAgRElBTU9ORCBCQVJCRVJTSE9QXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAgPGgxPkJva2EgdGlkPC9oMT5cblxuICAgICAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICAgICAgVsOkbGogYmVoYW5kbGluZywgYmFyYmVyYXJlIG9jaCB0aWQuXG4gICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBTVEVQUyAqL31cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0ZXBzXCI+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHN0ZXAgJHtzdGVwID49IDEgPyAnYWN0aXZlJyA6ICcnfWB9PlxuICAgICAgICAgICAgICAgICAgPHNwYW4+MTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxwPkJlaGFuZGxpbmc8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0ZXAtbGluZVwiIC8+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHN0ZXAgJHtzdGVwID49IDIgPyAnYWN0aXZlJyA6ICcnfWB9PlxuICAgICAgICAgICAgICAgICAgPHNwYW4+Mjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxwPkJhcmJlcmFyZTwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RlcC1saW5lXCIgLz5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgc3RlcCAke3N0ZXAgPj0gMyA/ICdhY3RpdmUnIDogJyd9YH0+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj4zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHA+VGlkPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGVwLWxpbmVcIiAvPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BzdGVwICR7c3RlcCA+PSA0ID8gJ2FjdGl2ZScgOiAnJ31gfT5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPjQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8cD5CZWtyw6RmdGE8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge21lc3NhZ2UgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVzc2FnZVwiPlxuICAgICAgICAgICAgICAgICAge21lc3NhZ2V9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIFNURVAgMSAqL31cblxuICAgICAgICAgICAgICB7c3RlcCA9PT0gMSAmJiAoXG4gICAgICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3RlcC1jb250ZW50XCI+XG5cbiAgICAgICAgICAgICAgICAgIDxoMj5Ww6RsaiBiZWhhbmRsaW5nPC9oMj5cblxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic3RlcC1kZXNjcmlwdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICBWYWQgdmlsbCBkdSBib2thP1xuICAgICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtbGlzdFwiPlxuXG4gICAgICAgICAgICAgICAgICAgIHtzZXJ2aWNlcy5tYXAoKHNlcnZpY2UpID0+IChcblxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHNlcnZpY2UtY2FyZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBib29raW5nLnNlcnZpY2U/LmlkID09PSBzZXJ2aWNlLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnc2VsZWN0ZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3NlcnZpY2UuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZWxlY3RTZXJ2aWNlKHNlcnZpY2UpfVxuICAgICAgICAgICAgICAgICAgICAgID5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXJ2aWNlLWluZm9cIj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDM+e3NlcnZpY2UubmFtZX08L2gzPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwPntzZXJ2aWNlLmRlc2NyaXB0aW9ufTwvcD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VydmljZS5kdXJhdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3NlcnZpY2UucHJpY2V9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3N0cm9uZz5cblxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICkpfVxuXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogU1RFUCAyICovfVxuXG4gICAgICAgICAgICAgIHtzdGVwID09PSAyICYmIChcbiAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzdGVwLWNvbnRlbnRcIj5cblxuICAgICAgICAgICAgICAgICAgPGgyPlbDpGxqIGJhcmJlcmFyZTwvaDI+XG5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInN0ZXAtZGVzY3JpcHRpb25cIj5cbiAgICAgICAgICAgICAgICAgICAgVmVtIHZpbGwgZHUgYm9rYSBob3M/XG4gICAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmFyYmVyLWxpc3RcIj5cblxuICAgICAgICAgICAgICAgICAgICB7YmFyYmVycy5tYXAoKGJhcmJlcikgPT4gKFxuXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmFyYmVyLWNhcmQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9va2luZy5iYXJiZXIgPT09IGJhcmJlclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ3NlbGVjdGVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtiYXJiZXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZWxlY3RCYXJiZXIoYmFyYmVyKX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmFyYmVyLWF2YXRhclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YmFyYmVyLmNoYXJBdCgwKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDM+e2JhcmJlcn08L2gzPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cD5CYXJiZXJhcmU8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICkpfVxuXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogU1RFUCAzICovfVxuXG4gICAgICAgICAgICAgIHtzdGVwID09PSAzICYmIChcbiAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzdGVwLWNvbnRlbnRcIj5cblxuICAgICAgICAgICAgICAgICAgPGgyPlbDpGxqIGRhdHVtIG9jaCB0aWQ8L2gyPlxuXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzdGVwLWRlc2NyaXB0aW9uXCI+XG4gICAgICAgICAgICAgICAgICAgIFNlIGhlbGEgdmVja2FucyB0aWxsZ8OkbmdsaWdhIHRpZGVyLlxuICAgICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndlZWstbGlzdFwiPlxuXG4gICAgICAgICAgICAgICAgICAgIHt3ZWVrRGF5cy5tYXAoKGRheSkgPT4gKFxuXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZGF5LWNvbHVtbiAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBib29raW5nLmRhdGUgPT09IGRheS5kYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnc2VsZWN0ZWQtZGF5J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtkYXkuZGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgY2xhc3NOYW1lPVwiZGF5LWhlYWRlclwiXG4gIGRhdGEtdGVzdGlkPXtgZGF5LSR7ZGF5LmRhdGV9YH1cbiAgb25DbGljaz17KCkgPT4gc2VsZWN0RGF0ZShkYXkuZGF0ZSl9XG4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkYXkuZGF5TmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2RheS5kYXlOdW1iZXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Ryb25nPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzbWFsbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGF5Lm1vbnRofVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NtYWxsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGF5LXRpbWVzXCI+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RpbWVzLm1hcCgodGltZSkgPT4ge1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYm9va2VkID0gaXNUaW1lQm9va2VkKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF5LmRhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2VsZWN0ZWQgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9va2luZy5kYXRlID09PSBkYXkuZGF0ZSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9va2luZy50aW1lID09PSB0aW1lXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICBrZXk9e3RpbWV9XG4gIGRpc2FibGVkPXtib29rZWR9XG4gIGRhdGEtdGVzdGlkPXtgdGltZS0ke2RheS5kYXRlfS0ke3RpbWV9YH1cbiAgY2xhc3NOYW1lPXtgd2Vlay10aW1lICR7c2VsZWN0ZWQgPyAnc2VsZWN0ZWQnIDogJyd9ICR7Ym9va2VkID8gJ2Jvb2tlZCcgOiAnJ31gfVxuICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgc2V0Qm9va2luZyh7XG4gICAgICAuLi5ib29raW5nLFxuICAgICAgZGF0ZTogZGF5LmRhdGUsXG4gICAgICB0aW1lLFxuICAgIH0pXG4gIH19XG4+XG4gIHtib29rZWQgPyAnQm9rYWQnIDogdGltZX1cbjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBTVEVQIDQgKi99XG5cbiAgICAgICAgICAgICAge3N0ZXAgPT09IDQgJiYgKFxuICAgICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInN0ZXAtY29udGVudFwiPlxuXG4gICAgICAgICAgICAgICAgICA8aDI+QmVrcsOkZnRhIGJva25pbmc8L2gyPlxuXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzdGVwLWRlc2NyaXB0aW9uXCI+XG4gICAgICAgICAgICAgICAgICAgIEtvbnRyb2xsZXJhIGRpbiBib2tuaW5nLlxuICAgICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbmZpcm1hdGlvblwiPlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QmVoYW5kbGluZzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Jvb2tpbmcuc2VydmljZT8ubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CYXJiZXJhcmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtib29raW5nLmJhcmJlcn1cbiAgICAgICAgICAgICAgICAgICAgICA8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5EYXR1bTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Jvb2tpbmcuZGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5UaWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtib29raW5nLnRpbWV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UHJpczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Jvb2tpbmcuc2VydmljZT8ucHJpY2V9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGZvcm1cbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJib29raW5nLWZvcm1cIlxuICAgICAgICAgICAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlU3VibWl0fVxuICAgICAgICAgICAgICAgICAgPlxuXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbD5OYW1uPC9sYWJlbD5cblxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImN1c3RvbWVyTmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEaXR0IG5hbW5cIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtib29raW5nLmN1c3RvbWVyTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+RS1wb3N0PC9sYWJlbD5cblxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjdXN0b21lckVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRpbiBlLXBvc3RcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtib29raW5nLmN1c3RvbWVyRW1haWx9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogTkFWSUdBVElPTiAqL31cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5hdmlnYXRpb25cIj5cblxuICAgICAgICAgICAgICAgIHtzdGVwID4gMSA/IChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmFjay1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtnb0JhY2t9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIOKGkCBUaWxsYmFrYVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgLz5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAge3N0ZXAgPCA0ID8gKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb250aW51ZS1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjb250aW51ZVRvTmV4dFN0ZXB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEZvcnRzw6R0dCDihpJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbnRpbnVlLWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICBmb3JtPVwiYm9va2luZy1mb3JtXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQmVrcsOkZnRhIGJva25pbmdcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgPC9tYWluPlxuICAgICAgKX1cblxuICAgICAgey8qIEJPT0tJTkdTICovfVxuXG4gICAgICB7cGFnZSA9PT0gJ2Jvb2tpbmdzJyAmJiAoXG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cInBhZ2UtY29udGFpbmVyXCI+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtaGVhZGluZ1wiPlxuXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLWxhYmVsXCI+XG4gICAgICAgICAgICAgIERJQU1PTkQgQkFSQkVSU0hPUFxuICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICA8aDE+TWluYSBib2tuaW5nYXI8L2gxPlxuXG4gICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgSMOkciBzZXIgZHUgZGluYSBib2thZGUgdGlkZXIuXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHtib29raW5ncy5sZW5ndGggPT09IDAgPyAoXG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wdHktYm9va2luZ3NcIj5cbiAgICAgICAgICAgICAgPGgyPkluZ2EgYm9rbmluZ2FyIMOkbm51PC9oMj5cblxuICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICBCb2thIGRpbiBmw7Zyc3RhIHRpZCBob3MgRGlhbW9uZCBCYXJiZXJzaG9wLlxuICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhlcm8tYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBnb1RvUGFnZSgnYm9va2luZycpfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQm9rYSB0aWRcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICkgOiAoXG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9va2luZy1oaXN0b3J5XCI+XG5cbiAgICAgICAgICAgICAge2Jvb2tpbmdzLm1hcCgoaXRlbSkgPT4gKFxuXG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlzdG9yeS1jYXJkXCJcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICA+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlzdG9yeS1kYXRlXCI+XG5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uYm9va2luZ0RhdGV9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmJvb2tpbmdUaW1lLnN1YnN0cmluZygwLCA1KX1cbiAgICAgICAgICAgICAgICAgICAgPC9zdHJvbmc+XG5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpc3RvcnktaW5mb1wiPlxuXG4gICAgICAgICAgICAgICAgICAgIDxoMz57aXRlbS5zZXJ2aWNlfTwvaDM+XG5cbiAgICAgICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICAgICAgQmFyYmVyYXJlOiB7aXRlbS5iYXJiZXJ9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5jdXN0b21lck5hbWV9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICApKX1cblxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICApfVxuXG4gICAgICAgIDwvbWFpbj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBDT05UQUNUICovfVxuXG4gICAgICB7cGFnZSA9PT0gJ2NvbnRhY3QnICYmIChcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwicGFnZS1jb250YWluZXJcIj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFnZS1oZWFkaW5nXCI+XG5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNlY3Rpb24tbGFiZWxcIj5cbiAgICAgICAgICAgICAgRElBTU9ORCBCQVJCRVJTSE9QXG4gICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgIDxoMT5Lb250YWt0YSBvc3M8L2gxPlxuXG4gICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgVmkgaGrDpGxwZXIgZGlnIGfDpHJuYS5cbiAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWdyaWRcIj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWNhcmRcIj5cbiAgICAgICAgICAgICAgPHNwYW4+QURSRVNTPC9zcGFuPlxuICAgICAgICAgICAgICA8aDM+U3RvY2tob2xtPC9oMz5cbiAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgQmVzw7ZrIG9zcyBmw7ZyIGRpbiBuw6RzdGEga2xpcHBuaW5nLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWNhcmRcIj5cbiAgICAgICAgICAgICAgPHNwYW4+VEVMRUZPTjwvc3Bhbj5cbiAgICAgICAgICAgICAgPGgzPjA4LTEyMyA0NSA2NzwvaDM+XG4gICAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICAgIFJpbmcgb3NzIHVuZGVyIHbDpXJhIMO2cHBldHRpZGVyLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWNhcmRcIj5cbiAgICAgICAgICAgICAgPHNwYW4+RS1QT1NUPC9zcGFuPlxuICAgICAgICAgICAgICA8aDM+aW5mb0BkaWFtb25kYmFyYmVyc2hvcC5zZTwvaDM+XG4gICAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICAgIFZpIHN2YXJhciBzw6Ugc25hcnQgdmkga2FuLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwvbWFpbj5cbiAgICAgICl9XG5cbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiZm9vdGVyXCI+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItbG9nb1wiPlxuICAgICAgICAgIERJQU1PTkRcbiAgICAgICAgICA8c3Bhbj5CQVJCRVJTSE9QPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8cD5cbiAgICAgICAgICDCqSAyMDI2IERpYW1vbmQgQmFyYmVyc2hvcFxuICAgICAgICA8L3A+XG5cbiAgICAgIDwvZm9vdGVyPlxuXG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwIl19